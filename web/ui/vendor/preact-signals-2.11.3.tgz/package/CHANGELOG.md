# @preact/signals

## 2.11.3

### Patch Changes

- [#991](https://github.com/preactjs/signals/pull/991) [`04445ba`](https://github.com/preactjs/signals/commit/04445ba15a095b7f11d5095ad83254bc180b05bc) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Don't re-run a `useSignalEffect` for a component that was unmounted by the same update. Preact 11 disposes it after paint, so the effect could otherwise run once more against an unmounted component.

## 2.11.2

### Patch Changes

- [#979](https://github.com/preactjs/signals/pull/979) [`7526ad0`](https://github.com/preactjs/signals/commit/7526ad0687e2c94c710fbd405d529c137594f043) Thanks [@andrewiggins](https://github.com/andrewiggins)! - Stop component tracking before Preact reconciles the returned VNode so Signals read by DOM property getters do not subscribe the parent component.

## 2.11.1

### Patch Changes

- [#973](https://github.com/preactjs/signals/pull/973) [`bb9cd0a`](https://github.com/preactjs/signals/commit/bb9cd0a1e58534d8c7cb5975ea0829c9dbc14268) Thanks [@developit](https://github.com/developit)! - Avoid closing over VNodes in component updater callbacks.

## 2.11.0

### Minor Changes

- [#968](https://github.com/preactjs/signals/pull/968) [`e83a981`](https://github.com/preactjs/signals/commit/e83a9815de29d661ebf843c2d34361f3ad4f9ed1) Thanks [@marvinhagemeister](https://github.com/marvinhagemeister)! - Add support for passing functions as fallback to `<For>` for lazy instantiation.

  ```tsx
  <For each={list} fallback={() => <p>No items</p>}>
  	{item => <p>{item}</p>}
  </For>
  ```

  This avoids eager evaluation of the fallback when the collection has items, which matters when you're dealing with signals.

## 2.10.1

### Patch Changes

- [#966](https://github.com/preactjs/signals/pull/966) [`950b2b8`](https://github.com/preactjs/signals/commit/950b2b81cec0a30af6260a56ec7cc2f55def900e) Thanks [@BPScott](https://github.com/BPScott)! - Export the `ModelFactory` type from the Preact and React adapters.

## 2.10.0

### Minor Changes

- [#954](https://github.com/preactjs/signals/pull/954) [`6b051b5`](https://github.com/preactjs/signals/commit/6b051b538622951a9bb10ba9655cb4ae12872f9a) Thanks [@marvinhagemeister](https://github.com/marvinhagemeister)! - Add support for passing functions as fallback to `<Show>` for lazy instantiation.

  ```tsx
  <Show when={toggle} fallback={() => <p>I'm lazy</p>}>
  	<p>foo</p>
  </Show>
  ```

  This avoids eager evaluation of whatever is passed to fallback which matters when you're dealing with signals.

### Patch Changes

- [#959](https://github.com/preactjs/signals/pull/959) [`b38cacf`](https://github.com/preactjs/signals/commit/b38cacf6045a65f1869ca5a154ce95d6a4209fa2) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Name signals created internally by the Preact adapter and `useLiveSignal` so debugging tools can identify them.

## 2.9.4

### Patch Changes

- [#952](https://github.com/preactjs/signals/pull/952) [`89000a2`](https://github.com/preactjs/signals/commit/89000a24d02bb352e2a1a2dcb971edda413184f4) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Stop treating `useContext` as hook state in the auto-memoization heuristic. Context updates force-update their subscribers in Preact, bypassing `shouldComponentUpdate` entirely, so context consumers can safely keep the props-based render skipping.

## 2.9.3

### Patch Changes

- [#950](https://github.com/preactjs/signals/pull/950) [`76f9155`](https://github.com/preactjs/signals/commit/76f9155815fe9f2918f98018984f7ec959cc0aea) Thanks [@joeyTedeschi](https://github.com/joeyTedeschi)! - Allow `<For>` to accept readonly arrays and signals containing readonly arrays.

- [#948](https://github.com/preactjs/signals/pull/948) [`6b0a76c`](https://github.com/preactjs/signals/commit/6b0a76cbc414a8e619fb00445318c2d37fc3b6d5) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Dispose signal prop updaters when an element re-renders without any signal props.

  The disposal pass only ran when the new render still carried at least one signal-bound prop. When every signal prop was replaced by plain values, the old updater effect stayed subscribed and kept writing the previous signal's values straight into the DOM, overriding whatever Preact rendered.

- Updated dependencies [[`2910fbf`](https://github.com/preactjs/signals/commit/2910fbf302ab2d914ff055f5159a0a75a6b86c49), [`d40746b`](https://github.com/preactjs/signals/commit/d40746be3c7575209d6325ff250c91dd72d6ef18)]:
  - @preact/signals-core@1.14.4

## 2.9.2

### Patch Changes

- [#942](https://github.com/preactjs/signals/pull/942) [`e76780c`](https://github.com/preactjs/signals/commit/e76780c7800febc10f57d15cd34166c2f19c65d0) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Fix stale `<For>` render-prop indexes after removals/reorders by making each cached item's index reactive (a per-item signal) instead of a frozen prop. Cached children are reused and re-render with the new index rather than being recreated, so DOM/component identity is preserved.

- [#938](https://github.com/preactjs/signals/pull/938) [`e0ce9fd`](https://github.com/preactjs/signals/commit/e0ce9fdf92df7f0ece2c89d44554c39f36dc6882) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Fix Signal-bound DOM props getting stranded at a stale value when Preact reuses a DOM node. The prop-binding effect now writes the applied value back into the rendered props, keeping Preact's diff baseline in sync with the DOM instead of assuming Preact applied every update.

- Updated dependencies [[`beb84c1`](https://github.com/preactjs/signals/commit/beb84c19d67c54d85e68ac033ac797b5792d1f8f)]:
  - @preact/signals-core@1.14.3

## 2.9.1

### Patch Changes

- [#924](https://github.com/preactjs/signals/pull/924) [`ebcee90`](https://github.com/preactjs/signals/commit/ebcee906dbf3e0de5ccf58cb2b10209e1d28b5ac) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Fix redundant DOM attribute writes when a parent rerenders with unchanged signal props. The DIFFED hook no longer writes Signal references back into `vnode.props`, which was causing Preact's prop diff to see a mismatch (old: Signal, new: peeked value) and re-apply every signal-bound attribute on every parent rerender.

## 2.9.0

### Minor Changes

- [#907](https://github.com/preactjs/signals/pull/907) [`904a879`](https://github.com/preactjs/signals/commit/904a8793a13021c738312809425dda8d54738510) Thanks [@jbalsas](https://github.com/jbalsas)! - Add optional `getKey` prop to `<For>` component for stable list reconciliation. When provided, `getKey` generates stable keys for the internal `<Item>` wrapper, fixing incorrect DOM reuse when items are removed or reordered.

## 2.8.2

### Patch Changes

- [#888](https://github.com/preactjs/signals/pull/888) [`d3c419d`](https://github.com/preactjs/signals/commit/d3c419d735492e164434f5486453da82660109b0) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Fix infinite recursion when tools like Storybook traverse Signal props

- Updated dependencies [[`308c921`](https://github.com/preactjs/signals/commit/308c921bbf189dd72861ef587f5e559d16299b68)]:
  - @preact/signals-core@1.14.0

## 2.8.1

### Patch Changes

- [#883](https://github.com/preactjs/signals/pull/883) [`849413f`](https://github.com/preactjs/signals/commit/849413f23a612ffeb3a159b4e65e0b0f4408ed9b) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Ensure that re-mounting components preserve the DOM updaters correctly

## 2.8.0

### Minor Changes

- [#878](https://github.com/preactjs/signals/pull/878) [`4aa565b`](https://github.com/preactjs/signals/commit/4aa565b3b668100b9c7ce09805da67cab8e3f5b2) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Support returning a plain array in the `when` of a `For` component

## 2.7.1

### Patch Changes

- [#870](https://github.com/preactjs/signals/pull/870) [`c8636fa`](https://github.com/preactjs/signals/commit/c8636fa69d9efcae86abc5503f69ff3d79a5b951) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Prevent scheduled effects from highjacking the execution-context

## 2.7.0

### Minor Changes

- [#861](https://github.com/preactjs/signals/pull/861) [`5794b04`](https://github.com/preactjs/signals/commit/5794b0418ef6a04810ade08e2a8237c66e61ed4b) Thanks [@andrewiggins](https://github.com/andrewiggins)! - Add `useModel` hook for using Models in components

  The new `useModel` hook provides a convenient way to use Models (created with `createModel`) within React and Preact components. It handles:
  - Creating the model instance lazily on first render
  - Maintaining the same instance across re-renders
  - Automatically disposing the model when the component unmounts

  ```jsx
  import { createModel, signal } from "@preact/signals-core";
  import { useModel } from "@preact/signals-react"; // or "@preact/signals"

  const CountModel = createModel(() => ({
  	count: signal(0),
  	increment() {
  		this.count.value++;
  	},
  }));

  function Counter() {
  	const model = useModel(CountModel);
  	return <button onClick={() => model.increment()}>{model.count}</button>;
  }
  ```

  For models that require constructor arguments, wrap in a factory function:

  ```jsx
  const CountModel = createModel((initialCount: number) => ({
    count: signal(initialCount),
  }));

  function Counter() {
    const model = useModel(() => new CountModel(5));
    return <div>{model.count}</div>;
  }
  ```

### Patch Changes

- [#865](https://github.com/preactjs/signals/pull/865) [`4872968`](https://github.com/preactjs/signals/commit/48729680775b593d3bc1d3c7c778e99fdf91c41a) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Revert https://github.com/preactjs/signals/pull/728 - this might entail work in prefresh but currently the presence of `uesState` makes every sCU bail

- Updated dependencies [[`19ac39b`](https://github.com/preactjs/signals/commit/19ac39bb4a7a3273090753a50a58efb717f5553d)]:
  - @preact/signals-core@1.13.0

## 2.6.2

### Patch Changes

- [#858](https://github.com/preactjs/signals/pull/858) [`e4bbb66`](https://github.com/preactjs/signals/commit/e4bbb66e3592343894ff880922ea1176742e3a13) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Fix issue where unmounted vnodes could update with signals

## 2.6.1

### Patch Changes

- [#836](https://github.com/preactjs/signals/pull/836) [`ac5032e`](https://github.com/preactjs/signals/commit/ac5032e63000cdb0bf84e20a1b44c161788a1607) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Ensure that the `For` and `Show` component have display-names

## 2.6.0

### Minor Changes

- [#819](https://github.com/preactjs/signals/pull/819) [`8a8b0d1`](https://github.com/preactjs/signals/commit/8a8b0d109d324a5764289674e580e693683de04d) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Remove the need for enter/exit component and track the effects normally

### Patch Changes

- [#827](https://github.com/preactjs/signals/pull/827) [`f17889b`](https://github.com/preactjs/signals/commit/f17889b6d46448205d9485b8d5e691fbe05cd404) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Add mangle entry for \_debugCallback

- Updated dependencies [[`f17889b`](https://github.com/preactjs/signals/commit/f17889b6d46448205d9485b8d5e691fbe05cd404)]:
  - @preact/signals-core@1.12.2

## 2.5.1

### Patch Changes

- [#795](https://github.com/preactjs/signals/pull/795) [`80712b1`](https://github.com/preactjs/signals/commit/80712b188b11b43efe9e95e09b78f57f0551f6eb) Thanks [@rschristian](https://github.com/rschristian)! - Widen utility component types to accept ComponentChildren/ReactNodes as children and fallbacks

- [#798](https://github.com/preactjs/signals/pull/798) [`e58734d`](https://github.com/preactjs/signals/commit/e58734d1ad752330c82b0ec949afda3d0cd114d2) Thanks [@marvinhagemeister](https://github.com/marvinhagemeister)! - Fix performance regression by checking if the `@preact/signals-debug` package is enabled only once.

- [#800](https://github.com/preactjs/signals/pull/800) [`bc5b573`](https://github.com/preactjs/signals/commit/bc5b573d3e24d1da2b1f91c051f70e57d7be6bc7) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Allow useLiveSignal to accept plain values

## 2.5.0

### Minor Changes

- [#792](https://github.com/preactjs/signals/pull/792) [`95dcf41`](https://github.com/preactjs/signals/commit/95dcf41c95baa5d9c6aa8f94c7592722c0cefc3f) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Allow the `when` property of `Show` to be a function so not everything has to be transformed into a boolean computed

### Patch Changes

- [#790](https://github.com/preactjs/signals/pull/790) [`4b143a7`](https://github.com/preactjs/signals/commit/4b143a7164d58edda05a23a482f06afc20543234) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Ensure the cached and non-cached shape is the same

- [#791](https://github.com/preactjs/signals/pull/791) [`358a758`](https://github.com/preactjs/signals/commit/358a7585a27deff6cf0b804f5f02739b893c7a02) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Prevent `For` cache from expanding infinitely

## 2.4.0

### Minor Changes

- [#777](https://github.com/preactjs/signals/pull/777) [`d31738f`](https://github.com/preactjs/signals/commit/d31738f646fda6bd00113b8e6e1dfae46e14f08e) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Revert the changes to `useComputed`, sincere apologies for the inconvenience we've discussed this at length and are going to side on the perf side.

### Patch Changes

- [#782](https://github.com/preactjs/signals/pull/782) [`fbf69a9`](https://github.com/preactjs/signals/commit/fbf69a904c425806b01ccf05c9834f9895918617) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Ensure aria/data attributes stick around when going back to an empty string

- [#783](https://github.com/preactjs/signals/pull/783) [`86575b4`](https://github.com/preactjs/signals/commit/86575b41ec097c3ecdefc7b54a4cabfbe23f7984) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Ensure `For` and `Show` account for nested reactivity

## 2.3.2

### Patch Changes

- [#754](https://github.com/preactjs/signals/pull/754) [`5db1295`](https://github.com/preactjs/signals/commit/5db1295fd46404c32802d89989d891d0389f7031) Thanks [@jviide](https://github.com/jviide)! - Update useComputed compute function on rerender

## 2.3.1

### Patch Changes

- [#744](https://github.com/preactjs/signals/pull/744) [`b178480`](https://github.com/preactjs/signals/commit/b17848089b3d396e0160e9d54a73d109d4674845) Thanks [@rschristian](https://github.com/rschristian)! - Correct semver range to support _beta_ releases of Preact v11

## 2.3.0

### Minor Changes

- [#727](https://github.com/preactjs/signals/pull/727) [`8fe8dec`](https://github.com/preactjs/signals/commit/8fe8decd9b5c6c4fd5b357730838eda030c25ae2) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Call into component tracking of the chrome extension

- [#681](https://github.com/preactjs/signals/pull/681) [`6cc7005`](https://github.com/preactjs/signals/commit/6cc700595278d241f276c40dd0ecf162c9e432d8) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Allow for naming your singals/computeds/effects

### Patch Changes

- [#728](https://github.com/preactjs/signals/pull/728) [`0fd9503`](https://github.com/preactjs/signals/commit/0fd9503a53ad6836ac445d7d384b8f153b93a158) Thanks [@marvinhagemeister](https://github.com/marvinhagemeister)! - Fix prefresh HMR not working with `useSignal`.

- [#729](https://github.com/preactjs/signals/pull/729) [`b45c2b6`](https://github.com/preactjs/signals/commit/b45c2b6e7e0c852a2df4ff7dd541864b4dd5c663) Thanks [@rschristian](https://github.com/rschristian)! - Expand semver range to support the upcoming v11 beta release

- Updated dependencies [[`6cc7005`](https://github.com/preactjs/signals/commit/6cc700595278d241f276c40dd0ecf162c9e432d8)]:
  - @preact/signals-core@1.12.0

## 2.2.1

### Patch Changes

- [#701](https://github.com/preactjs/signals/pull/701) [`01f406c`](https://github.com/preactjs/signals/commit/01f406c79b02ae6d262b751f220f35bed82394f2) Thanks [@calebeby](https://github.com/calebeby)! - Narrow types for Show utility, the callback is truthy by design

- Updated dependencies [[`4045d2d`](https://github.com/preactjs/signals/commit/4045d2d86b720546848d5163d5b683792c0a5af3)]:
  - @preact/signals-core@1.11.0

## 2.2.0

### Minor Changes

- [#634](https://github.com/preactjs/signals/pull/634) [`62bed44`](https://github.com/preactjs/signals/commit/62bed44b0f298ac0097060289bfecd73f030b146) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Add an option to specify a watched/unwatched callback to a signal

### Patch Changes

- Updated dependencies [[`587e702`](https://github.com/preactjs/signals/commit/587e702f8db9a8e67fe2cdf8dda0a4bffe5fc195), [`62bed44`](https://github.com/preactjs/signals/commit/62bed44b0f298ac0097060289bfecd73f030b146)]:
  - @preact/signals-core@1.9.0

## 2.1.1

### Patch Changes

- [#684](https://github.com/preactjs/signals/pull/684) [`a34eab2`](https://github.com/preactjs/signals/commit/a34eab2ab5a46f4ef90e05e2af6b99747191333c) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Ensure we build the thing

## 2.1.0

### Minor Changes

- [#683](https://github.com/preactjs/signals/pull/683) [`4b585a5`](https://github.com/preactjs/signals/commit/4b585a5f15300b73dc66f45effd21342e3f6e5d5) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Provide `@preact/signals/utils` package with some helpers to make working with signals easier in Preact

## 2.0.5

### Patch Changes

- [#677](https://github.com/preactjs/signals/pull/677) [`b990e7e`](https://github.com/preactjs/signals/commit/b990e7e5d643950be88df7b84e1cdadeb987eb8d) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - We reduce the raf timeout to be just above a timeout that is associated with a 30hz refresh rate. This ensures that for hidden frames the timeout drift can't be too large, the drift being too high could lead to unexpected situations.

- [#679](https://github.com/preactjs/signals/pull/679) [`f51eef4`](https://github.com/preactjs/signals/commit/f51eef4b95a1761f57c7c09ade9b0cb089b0792c) Thanks [@WeirdConstructor](https://github.com/WeirdConstructor)! - Fix accessing signals from Preact Class Component constructor.

## 2.0.4

### Patch Changes

- [#668](https://github.com/preactjs/signals/pull/668) [`36fcb2e`](https://github.com/preactjs/signals/commit/36fcb2e68876867f03fe5c8e3294a35386a885ff) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Correctly set peerDep of signals

## 2.0.3

### Patch Changes

- [#666](https://github.com/preactjs/signals/pull/666) [`f72e769`](https://github.com/preactjs/signals/commit/f72e769b885690c4dd53011ab2244015ffd35cb1) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Fix array signals when used as jsx

## 2.0.2

### Patch Changes

- [#655](https://github.com/preactjs/signals/pull/655) [`6a0284c`](https://github.com/preactjs/signals/commit/6a0284ca233e666e16fcab2584269e2344062519) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Avoid usage of `.base` and check the `_dom` on the vnode instead

- [#660](https://github.com/preactjs/signals/pull/660) [`df4df76`](https://github.com/preactjs/signals/commit/df4df765bdeef3e976969d865f8d386a5effebd8) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Bail out of the animation frame with a setTimeout in case the origin page is hidden

## 2.0.1

### Patch Changes

- [#647](https://github.com/preactjs/signals/pull/647) [`655905b`](https://github.com/preactjs/signals/commit/655905bc6e5ee8ba30d578e2a7bf02a9c83ee38c) Thanks [@jviide](https://github.com/jviide)! - Ensure that text effects get disposed

- [#630](https://github.com/preactjs/signals/pull/630) [`4b9144f`](https://github.com/preactjs/signals/commit/4b9144f7f13815013f78299dd487344d3750fd8f) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Change the way we deal with state settling hooks, when we know we are dealing with hooks that can settle their A -> B -> A state (and wind up at the same value). We should not verbatim rerender in our custom shouldComponentUpdate. Instead we should trust that hooks have handled their own state settling.

## 2.0.0

### Major Changes

- [#604](https://github.com/preactjs/signals/pull/604) [`fea3e8d`](https://github.com/preactjs/signals/commit/fea3e8da7a36944d87310678fad291aeacc55d8d) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Defer all DOM updates by an animation frame, this should make it so
  that any previously synchronous DOM update will be instead delayed by an
  animation frame. This allows Preact to first perform its own render
  cycle and then our direct DOM updates to occur. These will now
  be performed in a batched way which is more performant as the browser
  is prepared to handle these during the animation frame.

  This does impact how Preact based signals are tested, when
  you perform a signal update, you'll need to wrap it in `act`. In a way
  this was always the case, as a signal update that resulted in
  a Preact state update would require it to be wrapped in `act`, but
  now this is the norm.

### Minor Changes

- [#595](https://github.com/preactjs/signals/pull/595) [`499428a`](https://github.com/preactjs/signals/commit/499428aa7e7db3e250b3c257debf054a6368c010) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Align signal effects with animation-frames for better performance

### Patch Changes

- [#609](https://github.com/preactjs/signals/pull/609) [`8e6e2de`](https://github.com/preactjs/signals/commit/8e6e2de5a2af27832ea139a7b76fc63ae56cc1f1) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Change timing to a double microtask so we are behind the Preact render queue but can't delay as much as a user-input coming in.

## 1.3.0

### Minor Changes

- [#578](https://github.com/preactjs/signals/pull/578) [`931404e`](https://github.com/preactjs/signals/commit/931404e96338e120464b73e522148389e38eeb2b) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Allow for passing no argument to the signal and the type to be automatically inferred as `T | undefined`

### Patch Changes

- Updated dependencies [[`931404e`](https://github.com/preactjs/signals/commit/931404e96338e120464b73e522148389e38eeb2b)]:
  - @preact/signals-core@1.7.0

## 1.2.3

### Patch Changes

- [#535](https://github.com/preactjs/signals/pull/535) [`58befba`](https://github.com/preactjs/signals/commit/58befba577d02c5cac5292fda0a599f9708e908b) Thanks [@jviide](https://github.com/jviide)! - Publish packages with provenance statements

- Updated dependencies [[`d846def`](https://github.com/preactjs/signals/commit/d846defaf6e64f0236e2b91247e5f94a35f29cbc), [`cb6bdab`](https://github.com/preactjs/signals/commit/cb6bdabbd31b27f8435c7976089fa276da6bfb7a), [`d846def`](https://github.com/preactjs/signals/commit/d846defaf6e64f0236e2b91247e5f94a35f29cbc), [`d846def`](https://github.com/preactjs/signals/commit/d846defaf6e64f0236e2b91247e5f94a35f29cbc), [`d846def`](https://github.com/preactjs/signals/commit/d846defaf6e64f0236e2b91247e5f94a35f29cbc)]:
  - @preact/signals-core@1.6.0

## 1.2.2

### Patch Changes

- [#415](https://github.com/preactjs/signals/pull/415) [`79efe32`](https://github.com/preactjs/signals/commit/79efe32437784a2f7583fc727f9f99324289d11d) Thanks [@prinsss](https://github.com/prinsss)! - Fix error when using `useSignal` with UMD builds of `@preact/signals`.

## 1.2.1

### Patch Changes

- [#399](https://github.com/preactjs/signals/pull/399) [`24fa9f7`](https://github.com/preactjs/signals/commit/24fa9f791d70baba35bdce722f71ce63ac091a4d) Thanks [@rschristian](https://github.com/rschristian)! - Fixes UMD builds of `@preact/signals` and `@preact/signals-react`

## 1.2.0

### Minor Changes

- [#387](https://github.com/preactjs/signals/pull/387) [`6e4dab4`](https://github.com/preactjs/signals/commit/6e4dab4e8c99217aa2837037a5fc82ee852ee288) Thanks [@XantreGodlike](https://github.com/XantreGodlike)! - Removed difference in behaviour between adapters, signals that use a JSX value will correctly re-render the whole component rather than attempting the JSX-Text optimization.

### Patch Changes

- Updated dependencies [[`256a331`](https://github.com/preactjs/signals/commit/256a331b5335e54f7e918b3f1068fb9d92d1c613)]:
  - @preact/signals-core@1.4.0

## 1.1.5

### Patch Changes

- [#381](https://github.com/preactjs/signals/pull/381) [`e655e7f`](https://github.com/preactjs/signals/commit/e655e7f86c321dca12e760e21c01f2dbfafade47) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Allow for context to propagate to components using context

## 1.1.4

### Patch Changes

- [#373](https://github.com/preactjs/signals/pull/373) [`8c12a0d`](https://github.com/preactjs/signals/commit/8c12a0df74f00e9cab04e999fc443889b3528c04) Thanks [@rschristian](https://github.com/rschristian)! - Removes package.json#exports.umd, which had invalid paths if they were ever to be consumed

- Updated dependencies [[`8c12a0d`](https://github.com/preactjs/signals/commit/8c12a0df74f00e9cab04e999fc443889b3528c04), [`26f6526`](https://github.com/preactjs/signals/commit/26f6526875ef0968621c4113594ac95b93de5163)]:
  - @preact/signals-core@1.3.1

## 1.1.3

### Patch Changes

- [`df813ad`](https://github.com/preactjs/signals/commit/df813adc3ed304e326950be08509350cda43f28e) Thanks [@developit](https://github.com/developit)! - Fix rendering of Signals as text in `preact-render-to-string` (#268)

* [#282](https://github.com/preactjs/signals/pull/282) [`cafbdaa`](https://github.com/preactjs/signals/commit/cafbdaabd525a034e38da10b04eee0688c026152) Thanks [@developit](https://github.com/developit)! - Fix a bug that caused cleanup functions returned from a `useSignalEffect()` callback not to be called.

* Updated dependencies [[`7e15d3c`](https://github.com/preactjs/signals/commit/7e15d3cf5f5e66258105e6f27cd7838b52fbbf9f)]:
  - @preact/signals-core@1.2.3

## 1.1.2

### Patch Changes

- [#226](https://github.com/preactjs/signals/pull/226) [`ad29826`](https://github.com/preactjs/signals/commit/ad2982606a8894ea8562a0726d7777185987ad60) Thanks [@marvinhagemeister](https://github.com/marvinhagemeister)! - Fix hook names being mangled

- Updated dependencies [[`aa4cb7b`](https://github.com/preactjs/signals/commit/aa4cb7bfad744e78952cacc37af5bd4a713f0d3f), [`3f652a7`](https://github.com/preactjs/signals/commit/3f652a77d2a125a02a0cfc29fe661c81beeda16d)]:
  - @preact/signals-core@1.2.2

## 1.1.1

### Patch Changes

- [#198](https://github.com/preactjs/signals/pull/198) [`3db7500`](https://github.com/preactjs/signals/commit/3db7500beea4c447f22fbde80af7b5171afa171c) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - Fix server-sider-render error when unmounting a signal passed as text into JSX.

## 1.1.0

### Minor Changes

- [#91](https://github.com/preactjs/signals/pull/91) [`fb74bb9`](https://github.com/preactjs/signals/commit/fb74bb9ce4e44192e1ee7d3d041274cc985db767) Thanks [@JoviDeCroock](https://github.com/JoviDeCroock)! - add the `useSignalEffect` hook

* [#183](https://github.com/preactjs/signals/pull/183) [`79ff1e7`](https://github.com/preactjs/signals/commit/79ff1e794dde9952db2d6d43b22cebfb2accc770) Thanks [@jviide](https://github.com/jviide)! - Add ability to run custom cleanup logic when an effect is disposed.

  ```js
  effect(() => {
    console.log("This runs whenever a dependency changes");
    return () => {
      console.log("This runs when the effect is disposed");
    });
  });
  ```

### Patch Changes

- [#186](https://github.com/preactjs/signals/pull/186) [`7242bd6`](https://github.com/preactjs/signals/commit/7242bd68cc570c6159600f271ee95977d3970d0f) Thanks [@marvinhagemeister](https://github.com/marvinhagemeister)! - Fix unable to set SVG attribute via Signal

* [#161](https://github.com/preactjs/signals/pull/161) [`6ac6923`](https://github.com/preactjs/signals/commit/6ac6923e5294f8a31ee1a009550b9891c3996cb4) Thanks [@jviide](https://github.com/jviide)! - Remove all usages of `Set`, `Map` and other allocation heavy objects in signals-core. This substaintially increases performance across all measurements.

- [#171](https://github.com/preactjs/signals/pull/171) [`fcbb3f4`](https://github.com/preactjs/signals/commit/fcbb3f4b9077e201badec77b91f75c23623d1a9c) Thanks [@jviide](https://github.com/jviide)! - Reduce size of Preact adapter by replacing `WeakSet`s with bitmasks.

- Updated dependencies [[`b4611cc`](https://github.com/preactjs/signals/commit/b4611cc9dee0ae09f4b378ba293c3203edc32be4), [`9802da5`](https://github.com/preactjs/signals/commit/9802da5274bb45c3cc28dda961b9b2d18535729a), [`6ac6923`](https://github.com/preactjs/signals/commit/6ac6923e5294f8a31ee1a009550b9891c3996cb4), [`79ff1e7`](https://github.com/preactjs/signals/commit/79ff1e794dde9952db2d6d43b22cebfb2accc770), [`3e31aab`](https://github.com/preactjs/signals/commit/3e31aabb812ddb0f7451deba38267f8384eff9d1)]:
  - @preact/signals-core@1.2.0

## 1.0.4

### Patch Changes

- [#147](https://github.com/preactjs/signals/pull/147) [`3556499`](https://github.com/preactjs/signals/commit/355649903b766630b62cdd0f90a35d3eafa99fa9) Thanks [@developit](https://github.com/developit)! - Improve performance when rendering Signals as Text in Preact.

* [#148](https://github.com/preactjs/signals/pull/148) [`b948745`](https://github.com/preactjs/signals/commit/b948745de7b5b60a20ce3bdc5ee72d47d47f38ec) Thanks [@marvinhagemeister](https://github.com/marvinhagemeister)! - Move `types` field in `package.json` to the top of the entry list to ensure that TypeScript always finds it.

- [#153](https://github.com/preactjs/signals/pull/153) [`0da9ce3`](https://github.com/preactjs/signals/commit/0da9ce3c6f57cef67c3e84f0d829421aee8defff) Thanks [@developit](https://github.com/developit)! - Optimize the performance of prop bindings in Preact

- Updated dependencies [[`f2ba3d6`](https://github.com/preactjs/signals/commit/f2ba3d657bf8169c6ba1d47c0827aa18cfe1c947), [`160ea77`](https://github.com/preactjs/signals/commit/160ea7791f3adb55c562f5990e0b4848d8491a38), [`4385ea8`](https://github.com/preactjs/signals/commit/4385ea8c8358a154d8b789685bb061658ce1153f), [`b948745`](https://github.com/preactjs/signals/commit/b948745de7b5b60a20ce3bdc5ee72d47d47f38ec), [`00a59c6`](https://github.com/preactjs/signals/commit/00a59c6475bd4542fb934474d82d1e242b2ac870)]:
  - @preact/signals-core@1.1.1

## 1.0.3

### Patch Changes

- ab5bd99: Fix swapping and HMR for signals when used as text

## 1.0.2

### Patch Changes

- 2383684: Correctly replace props-value with peeked value
- Updated dependencies [5644c1f]
  - @preact/signals-core@1.0.1

## 1.0.1

### Patch Changes

- c7c0d91: Add marker for devtools to `Text` that is created when a signal is passed into JSX

## 1.0.0

### Major Changes

- 2ee8489: The v1 release for the signals package, we'd to see the uses you all
  come up with and are eager to see performance improvements in your
  applications.

### Patch Changes

- Updated dependencies [ab22ec7]
- Updated dependencies [2ee8489]
- Updated dependencies [b56abf3]
  - @preact/signals-core@1.0.0

## 0.0.4

### Patch Changes

- 702a9c5: Update TypeScript types to mark computed signals as readonly
- 5f8be64: Optimize size of CJS & UMD bundles.
- Updated dependencies [702a9c5]
  - @preact/signals-core@0.0.5

## 0.0.3

### Patch Changes

- 812e7b5: Fix `batch()` not re-exported from preact adapter
- 8e9bf67: Fix incorrect TypeScript paths
- f71ea95: Avoid incrementing Preact adapter when core changes
- Updated dependencies [4123d60]
  - @preact/signals-core@0.0.4

## 0.0.2

### Patch Changes

- 1e4dac5: Add `prepublishOnly` scripts to ensure we're publishing fresh packages
- 9ccf359: Align signal rendering in Text positions with VDOM text rendering - skip rendering of `null`, `undefined` and `boolean` values.
- 1171338: Fix wrong path for TypeScript definitions in `package.json`
- Updated dependencies [1e4dac5]
  - @preact/signals-core@0.0.3
